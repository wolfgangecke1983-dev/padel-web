const stats = [
  { value: "10×", label: "lebih cepat dari alur tradisional" },
  { value: "48 jam", label: "prototipe interaktif pertama" },
  { value: "120+", label: "produk dikirim ke produksi" },
  { value: "98%", label: "klien lanjut ke fase berikutnya" },
]

export function StatsBar() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto grid max-w-7xl grid-cols-2 md:grid-cols-4">
        {stats.map((stat, i) => (
          <div
            key={stat.label}
            className="border-border px-6 py-8 md:py-10 [&:nth-child(odd)]:border-r md:[&:not(:last-child)]:border-r md:[&:nth-child(odd)]:border-r [&:nth-child(-n+2)]:border-b md:[&:nth-child(-n+2)]:border-b-0"
          >
            <div className="text-3xl font-semibold tracking-tight text-foreground md:text-4xl">
              {stat.value}
            </div>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
