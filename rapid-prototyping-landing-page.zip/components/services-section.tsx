import { Globe, Rocket, AppWindow, ArrowUpRight } from "lucide-react"

const services = [
  {
    icon: Globe,
    title: "Website",
    desc: "Landing page, company profile, dan situs marketing yang cepat, responsif, dan dioptimalkan untuk konversi.",
    points: ["Desain custom", "SEO-ready", "Siap deploy ke Vercel"],
  },
  {
    icon: Rocket,
    title: "MVP",
    desc: "Validasi ide startup Anda dengan produk minimum yang fungsional — dibangun secepat kilat untuk diuji ke pasar.",
    points: ["Auth & database", "Iterasi cepat", "Skalabel sejak awal"],
    featured: true,
  },
  {
    icon: AppWindow,
    title: "Aplikasi",
    desc: "Web app & dashboard penuh fitur dengan logika bisnis nyata, integrasi, dan pengalaman pengguna yang matang.",
    points: ["Integrasi API", "Dashboard data", "Maintenance berkelanjutan"],
  },
]

export function ServicesSection() {
  return (
    <section id="layanan" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-sm uppercase tracking-widest text-primary">Layanan</p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Satu studio untuk seluruh siklus produk
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground md:text-lg">
            Desain, build, dan deploy ditangani dalam satu alur yang mulus —
            tanpa hand-off yang membuang waktu.
          </p>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon
            return (
              <div
                key={service.title}
                className={`group relative flex flex-col rounded-xl border p-7 transition-colors ${
                  service.featured
                    ? "border-primary/40 bg-primary/5"
                    : "border-border bg-card hover:border-border/80"
                }`}
              >
                <div
                  className={`flex size-11 items-center justify-center rounded-lg ${
                    service.featured
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-foreground"
                  }`}
                >
                  <Icon className="size-5" />
                </div>

                <h3 className="mt-5 flex items-center gap-2 text-xl font-semibold">
                  {service.title}
                  {service.featured && (
                    <span className="rounded-full bg-primary px-2 py-0.5 text-xs font-medium text-primary-foreground">
                      Populer
                    </span>
                  )}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{service.desc}</p>

                <ul className="mt-6 space-y-2 border-t border-border pt-6">
                  {service.points.map((p) => (
                    <li key={p} className="flex items-center gap-2 text-sm text-foreground">
                      <span className="size-1.5 rounded-full bg-primary" />
                      {p}
                    </li>
                  ))}
                </ul>

                <a
                  href="#kontak"
                  className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-foreground transition-colors hover:text-primary"
                >
                  Diskusikan proyek
                  <ArrowUpRight className="size-4" />
                </a>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
