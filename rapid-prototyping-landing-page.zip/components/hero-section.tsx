import { ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden border-b border-border">
      {/* grid backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.18]"
        style={{
          backgroundImage:
            "linear-gradient(to right, var(--border) 1px, transparent 1px), linear-gradient(to bottom, var(--border) 1px, transparent 1px)",
          backgroundSize: "64px 64px",
          maskImage: "radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-6 pb-20 pt-20 md:pb-28 md:pt-28">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-1.5 text-sm text-muted-foreground">
            <Sparkles className="size-3.5 text-primary" />
            AI-powered design & development studio
          </div>

          <h1 className="text-balance text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
            Dari ide ke produk siap deploy{" "}
            <span className="text-primary">10x lebih cepat</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            Kami memangkas alur lambat Figma → developer → deploy. Dengan rapid
            prototyping berbasis AI, website, MVP, dan aplikasi Anda lahir dalam
            hitungan hari — bukan bulan.
          </p>

          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" className="group rounded-full px-6 font-medium" asChild>
              <a href="#kontak">
                Mulai Prototipe
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
              </a>
            </Button>
            <Button size="lg" variant="outline" className="rounded-full border-border bg-transparent px-6" asChild>
              <a href="#proses">Lihat cara kerja</a>
            </Button>
          </div>

          <p className="mt-5 text-sm text-muted-foreground">
            Prototipe pertama dalam 48 jam. Tanpa biaya di muka.
          </p>
        </div>
      </div>
    </section>
  )
}
