import { Check, X } from "lucide-react"

const oldFlow = [
  "Riset & wireframe manual di Figma",
  "Revisi desain bolak-balik berhari-hari",
  "Hand-off ke developer + dokumentasi",
  "Developer menerjemahkan ulang desain",
  "Bug, miskomunikasi, lalu QA panjang",
  "Deploy setelah berminggu-minggu",
]

const newFlow = [
  "Brief & arah visual disepakati cepat",
  "AI generate prototipe interaktif nyata",
  "Iterasi langsung di produk hidup",
  "Desain = kode, tanpa hand-off",
  "Validasi dengan pengguna sejak awal",
  "Deploy ke produksi dalam hitungan hari",
]

const steps = [
  {
    no: "01",
    title: "Discovery",
    desc: "Kami memahami tujuan, pengguna, dan ruang lingkup produk Anda dalam satu sesi singkat.",
  },
  {
    no: "02",
    title: "Prototipe AI",
    desc: "Dalam 48 jam, prototipe interaktif yang bisa diklik — bukan sekadar gambar statis.",
  },
  {
    no: "03",
    title: "Iterasi langsung",
    desc: "Feedback Anda diterapkan secara real-time pada produk yang benar-benar berjalan.",
  },
  {
    no: "04",
    title: "Deploy",
    desc: "Produk live di domain Anda, siap dipakai pengguna dan diskalakan kapan pun.",
  },
]

export function ProcessSection() {
  return (
    <section id="proses" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-sm uppercase tracking-widest text-primary">Cara Kerja</p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Buang alur lama yang lambat
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground md:text-lg">
            Alur tradisional kehilangan momentum di setiap hand-off. Kami
            menyatukan desain dan kode menjadi satu proses berkelanjutan.
          </p>
        </div>

        {/* comparison */}
        <div className="mt-12 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-border bg-card p-7">
            <h3 className="text-lg font-semibold text-muted-foreground">Cara tradisional</h3>
            <p className="mt-1 text-sm text-muted-foreground">Figma → developer → deploy</p>
            <ul className="mt-6 space-y-3">
              {oldFlow.map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm text-muted-foreground">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-secondary">
                    <X className="size-3" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-6 border-t border-border pt-4 text-sm font-medium text-muted-foreground">
              Rata-rata: 6–12 minggu
            </p>
          </div>

          <div className="rounded-xl border border-primary/40 bg-primary/5 p-7">
            <h3 className="text-lg font-semibold text-foreground">Cara Velo</h3>
            <p className="mt-1 text-sm text-primary">Rapid prototyping dengan AI</p>
            <ul className="mt-6 space-y-3">
              {newFlow.map((item) => (
                <li key={item} className="flex items-start gap-3 text-sm text-foreground">
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Check className="size-3" strokeWidth={3} />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
            <p className="mt-6 border-t border-primary/20 pt-4 text-sm font-medium text-foreground">
              Rata-rata: 3–10 hari
            </p>
          </div>
        </div>

        {/* steps */}
        <div className="mt-16 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <div key={step.no} className="bg-card p-7">
              <span className="font-mono text-sm text-primary">{step.no}</span>
              <h4 className="mt-4 text-lg font-semibold">{step.title}</h4>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
