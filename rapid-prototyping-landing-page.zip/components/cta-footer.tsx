import { ArrowRight, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CtaFooter() {
  return (
    <>
      <section id="kontak" className="relative overflow-hidden border-b border-border">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-[0.18]"
          style={{
            backgroundImage:
              "linear-gradient(to right, var(--border) 1px, transparent 1px), linear-gradient(to bottom, var(--border) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
            maskImage: "radial-gradient(ellipse 70% 80% at 50% 50%, black 30%, transparent 100%)",
          }}
        />
        <div className="relative mx-auto max-w-3xl px-6 py-24 text-center md:py-32">
          <h2 className="text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Punya ide? Mari ubah jadi produk minggu ini.
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-pretty text-muted-foreground md:text-lg">
            Ceritakan apa yang ingin Anda bangun. Kami balas dengan rencana
            prototipe konkret — gratis, tanpa kewajiban.
          </p>

          <form
            className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
            action="#"
          >
            <label htmlFor="email" className="sr-only">
              Alamat email
            </label>
            <input
              id="email"
              type="email"
              required
              placeholder="email@perusahaan.com"
              className="h-11 flex-1 rounded-full border border-border bg-card px-5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary"
            />
            <Button type="submit" size="lg" className="group rounded-full px-6 font-medium">
              Mulai
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
          </form>
        </div>
      </section>

      <footer className="bg-background">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="flex flex-col items-start justify-between gap-8 md:flex-row md:items-center">
            <div>
              <a href="#" className="flex items-center gap-2" aria-label="Velo beranda">
                <span className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <Zap className="size-4" strokeWidth={2.5} />
                </span>
                <span className="text-lg font-semibold tracking-tight">Velo</span>
              </a>
              <p className="mt-3 max-w-xs text-sm text-muted-foreground">
                Studio AI rapid prototyping untuk website, MVP, dan aplikasi.
              </p>
            </div>

            <nav className="flex flex-wrap gap-x-8 gap-y-3 text-sm">
              <a href="#layanan" className="text-muted-foreground transition-colors hover:text-foreground">
                Layanan
              </a>
              <a href="#proses" className="text-muted-foreground transition-colors hover:text-foreground">
                Cara Kerja
              </a>
              <a href="#hasil" className="text-muted-foreground transition-colors hover:text-foreground">
                Hasil
              </a>
              <a href="#harga" className="text-muted-foreground transition-colors hover:text-foreground">
                Harga
              </a>
            </nav>
          </div>

          <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-border pt-6 text-sm text-muted-foreground sm:flex-row sm:items-center">
            <p>© {new Date().getFullYear()} Velo Studio. Semua hak dilindungi.</p>
            <div className="flex gap-6">
              <a href="#" className="transition-colors hover:text-foreground">
                Privasi
              </a>
              <a href="#" className="transition-colors hover:text-foreground">
                Ketentuan
              </a>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}
