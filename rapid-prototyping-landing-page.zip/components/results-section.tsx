const testimonials = [
  {
    company: "Nimbus",
    quote:
      "Yang biasanya butuh tiga bulan dengan agency lama, selesai dalam dua minggu. Prototipe interaktifnya langsung kami pakai untuk pitch ke investor.",
    name: "Raka Pradana",
    role: "Founder, Nimbus",
    metric: "2 minggu",
    metricLabel: "ide ke MVP",
  },
  {
    company: "Lumina",
    quote:
      "Tidak ada lagi miskomunikasi antara desainer dan developer. Apa yang kami lihat di prototipe persis seperti yang di-deploy.",
    name: "Sinta Maharani",
    role: "Product Lead, Lumina",
    metric: "0 hand-off",
    metricLabel: "desain langsung jadi kode",
  },
  {
    company: "Kairos",
    quote:
      "Kecepatan iterasinya gila. Kami uji empat versi landing page dalam satu minggu dan menaikkan konversi secara signifikan.",
    name: "Dimas Aryo",
    role: "CMO, Kairos",
    metric: "+64%",
    metricLabel: "kenaikan konversi",
  },
]

export function ResultsSection() {
  return (
    <section id="hasil" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-sm uppercase tracking-widest text-primary">Hasil</p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Tim yang kami percepat
          </h2>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure
              key={t.company}
              className="flex flex-col justify-between rounded-xl border border-border bg-card p-7"
            >
              <div>
                <div className="text-lg font-semibold tracking-tight">{t.company}</div>
                <blockquote className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">
                  {`"${t.quote}"`}
                </blockquote>
              </div>

              <div className="mt-8">
                <div className="rounded-lg border border-border bg-secondary/40 px-4 py-3">
                  <div className="text-2xl font-semibold text-primary">{t.metric}</div>
                  <div className="text-xs text-muted-foreground">{t.metricLabel}</div>
                </div>
                <figcaption className="mt-4 text-sm">
                  <span className="font-medium text-foreground">{t.name}</span>
                  <span className="block text-muted-foreground">{t.role}</span>
                </figcaption>
              </div>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
