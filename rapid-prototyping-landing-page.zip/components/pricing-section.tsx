import { Check, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const plans = [
  {
    name: "Sprint",
    price: "Rp 8jt",
    period: "/ proyek",
    desc: "Untuk landing page & website marketing yang butuh cepat live.",
    features: ["1 halaman utama + section", "Desain custom", "Responsif & SEO-ready", "Deploy ke Vercel", "Prototipe dalam 48 jam"],
    cta: "Mulai Sprint",
  },
  {
    name: "Launch",
    price: "Rp 25jt",
    period: "/ proyek",
    desc: "Untuk MVP startup yang siap divalidasi ke pasar.",
    features: ["Multi-halaman + auth", "Database & integrasi", "Iterasi tak terbatas (2 minggu)", "Dashboard pengguna", "Handover kode penuh", "Dukungan prioritas"],
    cta: "Mulai Launch",
    featured: true,
  },
  {
    name: "Scale",
    price: "Custom",
    period: "",
    desc: "Untuk aplikasi penuh fitur & kerja sama berkelanjutan.",
    features: ["Aplikasi web kompleks", "Arsitektur skalabel", "Integrasi sistem internal", "Retainer bulanan", "SLA & maintenance", "Tim dedikasi"],
    cta: "Hubungi kami",
  },
]

export function PricingSection() {
  return (
    <section id="harga" className="border-b border-border">
      <div className="mx-auto max-w-7xl px-6 py-20 md:py-28">
        <div className="max-w-2xl">
          <p className="font-mono text-sm uppercase tracking-widest text-primary">Harga</p>
          <h2 className="mt-4 text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Transparan, sesuai skala proyek
          </h2>
          <p className="mt-4 text-pretty text-muted-foreground md:text-lg">
            Pilih titik mulai Anda. Semua paket dimulai dengan prototipe sebelum
            ada komitmen besar.
          </p>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`flex flex-col rounded-xl border p-7 ${
                plan.featured ? "border-primary/50 bg-primary/5" : "border-border bg-card"
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">{plan.name}</h3>
                {plan.featured && (
                  <span className="rounded-full bg-primary px-2.5 py-0.5 text-xs font-medium text-primary-foreground">
                    Paling dipilih
                  </span>
                )}
              </div>

              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-semibold tracking-tight">{plan.price}</span>
                <span className="text-sm text-muted-foreground">{plan.period}</span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{plan.desc}</p>

              <ul className="mt-6 flex-1 space-y-3 border-t border-border pt-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-primary" strokeWidth={2.5} />
                    <span className="text-foreground">{f}</span>
                  </li>
                ))}
              </ul>

              <Button
                className="group mt-8 w-full rounded-full font-medium"
                variant={plan.featured ? "default" : "outline"}
                asChild
              >
                <a href="#kontak">
                  {plan.cta}
                  <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
                </a>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
